package com.example.tamillettercards

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioGroup
import android.widget.RadioButton
import android.widget.TextView
import android.widget.FrameLayout
import android.graphics.drawable.GradientDrawable
import kotlin.random.Random

class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private var intervalSeconds = 2
    private var running = false
    private var shownCount = 0
    private var currentLetter = "அ"
    private lateinit var letterView: TextView
    private lateinit var card: FrameLayout
    private lateinit var statusView: TextView
    private lateinit var startButton: Button
    private lateinit var nextButton: Button
    private lateinit var intervalGroup: RadioGroup

    private val vowels = listOf("அ", "ஆ", "இ", "ஈ", "உ", "ஊ", "எ", "ஏ", "ஐ", "ஒ", "ஓ", "ஔ")
    private val consonants = listOf("க", "ங", "ச", "ஞ", "ட", "ண", "த", "ந", "ப", "ம", "ய", "ர", "ல", "வ", "ழ", "ள", "ற", "ன")
    private val vowelSigns = listOf("", "ா", "ி", "ீ", "ு", "ூ", "ெ", "ே", "ை", "ொ", "ோ", "ௌ")
    private val letters: List<String> = buildList {
        addAll(vowels)
        addAll(consonants)
        for (c in consonants) for (sign in vowelSigns) add(c + sign)
        add("ஃ")
    }

    private val palette = listOf(
        0xFFFFE0E6.toInt(), 0xFFDDF4FF.toInt(), 0xFFE4F7D2.toInt(),
        0xFFFFE8C2.toInt(), 0xFFE9E0FF.toInt(), 0xFFFFF4B8.toInt(),
        0xFFD4F5E9.toInt(), 0xFFFFDCCF.toInt(), 0xFFDCE5FF.toInt(),
        0xFFF8DDF2.toInt(), 0xFFE8F0D5.toInt(), 0xFFD8F3F0.toInt()
    )

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            showRandomLetter()
            handler.postDelayed(this, intervalSeconds * 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(248, 249, 252)
        window.navigationBarColor = Color.rgb(248, 249, 252)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        buildUi()
        showRandomLetter()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(18))
            setBackgroundColor(Color.rgb(248, 249, 252))
        }

        val title = TextView(this).apply {
            text = "தமிழ் எழுத்துகள்"
            textSize = 25f
            setTextColor(Color.rgb(35, 43, 61))
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            gravity = Gravity.CENTER
        }
        root.addView(title, LinearLayout.LayoutParams(-1, dp(44)))

        val subtitle = TextView(this).apply {
            text = "247 எழுத்துகள் • Random Letter Cards"
            textSize = 13f
            setTextColor(Color.rgb(105, 112, 128))
            gravity = Gravity.CENTER
        }
        root.addView(subtitle, LinearLayout.LayoutParams(-1, dp(28)))

        card = FrameLayout(this).apply {
            background = rounded(palette.random(), dp(28))
            elevation = dp(4).toFloat()
        }
        letterView = TextView(this).apply {
            text = "அ"
            textSize = 112f
            setTextColor(Color.rgb(36, 42, 56))
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            gravity = Gravity.CENTER
            includeFontPadding = true
        }
        card.addView(letterView, FrameLayout.LayoutParams(-1, -1))
        val cardParams = LinearLayout.LayoutParams(-1, 0, 1f).apply {
            topMargin = dp(22)
            bottomMargin = dp(18)
        }
        root.addView(card, cardParams)

        statusView = TextView(this).apply {
            text = "Letters shown: 0 / 247"
            textSize = 14f
            setTextColor(Color.rgb(95, 103, 120))
            gravity = Gravity.CENTER
        }
        root.addView(statusView, LinearLayout.LayoutParams(-1, dp(28)))

        val intervalLabel = TextView(this).apply {
            text = "Change interval"
            textSize = 15f
            setTextColor(Color.rgb(45, 52, 69))
            gravity = Gravity.CENTER
        }
        val labelParams = LinearLayout.LayoutParams(-1, dp(30)).apply { topMargin = dp(8) }
        root.addView(intervalLabel, labelParams)

        intervalGroup = RadioGroup(this).apply {
            orientation = RadioGroup.HORIZONTAL
            gravity = Gravity.CENTER
        }
        listOf(1, 2, 3, 4, 5).forEach { seconds ->
            val radio = RadioButton(this).apply {
                id = seconds
                text = "${seconds}s"
                textSize = 14f
                buttonTintList = android.content.res.ColorStateList.valueOf(Color.rgb(91, 95, 205))
                setTextColor(Color.rgb(48, 54, 72))
                setPadding(dp(4), 0, dp(4), 0)
            }
            intervalGroup.addView(radio, RadioGroup.LayoutParams(0, dp(48), 1f))
        }
        intervalGroup.check(2)
        intervalGroup.setOnCheckedChangeListener { _, checkedId ->
            if (checkedId in 1..5) {
                intervalSeconds = checkedId
                if (running) {
                    handler.removeCallbacks(tick)
                    handler.postDelayed(tick, intervalSeconds * 1000L)
                }
            }
        }
        root.addView(intervalGroup, LinearLayout.LayoutParams(-1, dp(48)))

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        startButton = Button(this).apply {
            text = "Start"
            isAllCaps = false
            setOnClickListener { toggleRunning() }
        }
        nextButton = Button(this).apply {
            text = "Next letter"
            isAllCaps = false
            setOnClickListener {
                showRandomLetter()
                if (running) {
                    handler.removeCallbacks(tick)
                    handler.postDelayed(tick, intervalSeconds * 1000L)
                }
            }
        }
        buttons.addView(startButton, LinearLayout.LayoutParams(0, dp(54), 1f).apply { marginEnd = dp(6) })
        buttons.addView(nextButton, LinearLayout.LayoutParams(0, dp(54), 1f).apply { marginStart = dp(6) })
        root.addView(buttons, LinearLayout.LayoutParams(-1, dp(58)))

        val note = TextView(this).apply {
            text = "Every letter has the same chance on each draw."
            textSize = 12f
            setTextColor(Color.rgb(115, 121, 136))
            gravity = Gravity.CENTER
        }
        root.addView(note, LinearLayout.LayoutParams(-1, dp(34)))

        setContentView(root)
    }

    private fun toggleRunning() {
        running = !running
        if (running) {
            startButton.text = "Pause"
            handler.removeCallbacks(tick)
            handler.postDelayed(tick, intervalSeconds * 1000L)
        } else {
            startButton.text = "Resume"
            handler.removeCallbacks(tick)
        }
    }

    private fun showRandomLetter() {
        // Uniform selection from the full 247-letter list: every entry has probability 1/247.
        currentLetter = letters[Random.nextInt(letters.size)]
        shownCount++
        letterView.text = currentLetter
        card.background = rounded(palette.random(), dp(28))
        statusView.text = "Letters shown: $shownCount  •  Unique letters: ${letters.distinct().size}"
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
