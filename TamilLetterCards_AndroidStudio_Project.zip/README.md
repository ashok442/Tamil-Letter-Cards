# Tamil Letter Cards (Android)

A native Android app that displays randomly selected Tamil letters on colourful cards.

## Features
- Includes the standard 247 Tamil letters: 12 vowels, 18 consonants, 216 consonant-vowel combinations, and ஃ.
- Random pastel card colours.
- Medium-weight, large Tamil letter display.
- Adjustable automatic interval: 1, 2, 3, 4, or 5 seconds.
- Start/Pause/Resume and Next Letter controls.
- Uniform random selection: each of the 247 entries has a 1/247 chance on each draw. Repeats can occur, as expected with independent random selection.

## Build an APK
1. Install Android Studio and its Android SDK (API 35 or a compatible installed SDK).
2. Open this folder in Android Studio and allow Gradle sync.
3. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The debug APK will be created under `app/build/outputs/apk/debug/`.

Application ID: `com.example.tamillettercards`
Minimum Android version: Android 6.0 (API 23).

## Note
The standard 247-letter set is represented as 12 independent vowels + 18 consonants + 216 uyirmei combinations + aytham (ஃ). Some educational conventions may group or display these differently.
